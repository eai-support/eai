---
name: gofer:vocabulary
description: "Extract domain terminology into a canonical feature glossary."
title: 'Gofer Vocabulary'
category: control
surfaces:
  - claude
  - claude-mirror
  - copilot
  - vscode
  - codex
  - gemini
  - github-prompts
  - agents-skills
  - system-skills
---

# Gofer Vocabulary

## EAI Platform Session Preflight

Before any Gofer stage/helper command does pipeline work:

1. Treat durable delivery as EAI Platform delivery by default, with Azure second
   and every other stack only by explicit exception.
2. Run `eai whoami` and confirm the EAI CLI is installed, the user is logged in,
   and an active workspace is visible.
3. If `eai` is missing, `eai whoami` fails, the token is expired, or no active
   workspace is available, stop and run `/gofer:eai-first-run` or ask the user to
   approve login/setup before continuing.
4. For EAI app delivery, do not continue into research, specification, planning,
   tasks, implementation, or validation until
   `.specify/specs/{feature}/eai-preflight.md` records login, workspace, template,
   app-readiness, and next-action evidence.
5. Do not write tokens, secrets, private workspace IDs, Entra/CIAM authority tenant IDs, or local `.env` values into
   Gofer artifacts; record only product-safe readiness status and evidence.

## Token And Cost Policy
<!-- gofer:token-cost-policy:start -->

Before spawning agents, calling tools, or loading large files:

1. Treat `.specify/memory/gofer-model-policy.yaml` as the repo-owned source of truth for simple, medium, hard, and arbiter model routing. If it is missing, run `/gofer:bootstrap-workspace` before continuing.
2. Use the cheapest capable model first.
   - Claude: Haiku for scouting/extraction; Sonnet for normal implementation, synthesis, validation, and security; Opus for high-risk arbitration or release-critical failures.
   - Codex/OpenAI: GPT mini for simple coding; GPT nano only for locate/classify/summarize/mechanical work; GPT-5.3-Codex or flagship GPT for tool-heavy coding, architecture, and release-critical validation.
   - Gemini: Flash-Lite for cheap large-context scan/summarize; Flash for default research synthesis; Pro for large-context architecture or high-risk arbitration.
   - Copilot: prefer Auto for simple and default work; ask the user before choosing a paid/high-tier picker model for hard security, architecture, or release gates.
3. Keep raw tool output out of the main conversation context. Save stable findings to `.specify/specs/{feature}/context-bundle.md`, then work from summaries.
4. Use provider prompt/context caching only for stable, non-secret prefixes: Gofer scaffold, AGENTS/CLAUDE/Copilot instructions, constitution, repo map, stage contracts, and validation rubric.
5. Before continuing after large research, planning, implementation, or validation bursts, checkpoint the durable artifacts and compact/clear/resume context when the host supports it.
6. Escalate model tier only when a cheaper pass is low-confidence, contradictory, security-sensitive, or blocking release quality.
<!-- gofer:token-cost-policy:end -->

Extract the feature's shared domain language into a canonical glossary and
write it to `.specify/specs/{feature}/glossary.md`.

Use this when research, specification, contracts, or implementation rely on
terms that need stable definitions across Claude, Copilot, Codex, and Gemini
surfaces.

When you run this helper:

1. Read the feature-local context that already exists (`research.md`, `spec.md`,
   `plan.md`, `contracts/`, `quickstart.md`) and ignore unrelated repository
   content.
2. Identify project-specific terms, acronyms, role names, workflow names, and
   overloaded words that need precise definitions.
3. Write the artifact only to `.specify/specs/{feature}/glossary.md`. Never
   write to repo root or any provider-specific surface directory.
4. If the target file already exists, replace it and prepend a regeneration note
   such as `<!-- regenerated at [ISO timestamp] -->`.
5. Include the minimum provenance schema:
   - `GeneratedAt`
   - `SourceCommandId`
   - `SourceInputs`
   - `OverwriteNoticeWhenApplicable`

The generated glossary must contain these sections:

- `## Provenance`
- `## Term Entries`
- `## Definitions`
- `## Source Artifacts`

Keep the content Gofer-owned and concise. Do not copy upstream Matt Pocock
skill text verbatim.
